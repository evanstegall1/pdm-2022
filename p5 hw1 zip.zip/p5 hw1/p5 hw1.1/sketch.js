function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(0, 255, 0);
  circle(100, 100, 160);
  square(220, 20, 160);
}